#ifndef COFFEE_PIXELFORMAT_HPP
#define COFFEE_PIXELFORMAT_HPP

namespace cf
{
    enum class PixelFormat
    {
        RGB,
        RGBA
    };
}

#endif // COFFEE_PIXELFORMAT_HPP