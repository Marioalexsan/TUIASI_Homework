# RC-Proiect
Python project for RC-P project of AC TUIAȘI.
Buna siua!
