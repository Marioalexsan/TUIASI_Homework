# IP-Proiect
Proiect la Ingineria Programării, @TUIAȘI

* Temă: IDE C / C++
* Echipă:
  * Damian Gabriel-Mihai, 1308B
  * Florea Alexandru-Daniel, 1308B
  * Miron Alexandru, 1308B
  * Tutuianu Robert-Constantin, 1308B

* Taskuri:
  * Damian - Fisiere proiect
    * New project
    * Open project
    * Add / create file
    * Discover existing files
  * Florea - Elemente editor
    * Copy, paste, redo, undo
    * Meniu contextual (copy, paste, delete, cut...)
    * Shortcuts
  * Miron - sintax higlighting / warning errors
    * Rich Text Box
    * Elemente de la materia LFT
    * Nice to have: warnings / errors în timpul editării
    * Must have: warnings / errors at build time
  * Țuțuianu - build script:
    * Buton build / rebuild
    * Buton run
    * Elemente de redirectare consolă, output compilator
    * Nice to have: debugging basic (breakpointuri, valori)
  * Pentru fiecare modul / coechipier
    * Documentație
    * UML
    * Fișiere help
    * Elemente GUI
