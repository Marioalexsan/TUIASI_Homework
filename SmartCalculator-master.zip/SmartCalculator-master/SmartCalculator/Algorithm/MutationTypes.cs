﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartCalculator.Algorithm;

public enum MutationTypes
{
    Rand1 = 0,
    Best1,
    Best2,
    CurrentToBest1
}
